import ShaderHero from "@/components/ui/shader-hero";
import { Cloud, FileCheck2, ScanLine, ShieldCheck } from "lucide-react";

const features = [
  ["Scan & Check", "สแกน QR และอ่านใบคำตอบ โดยส่งข้อที่ไม่ชัดให้ครูตรวจ", ScanLine],
  ["Google Drive", "ไฟล์ของครูแต่ละคนเก็บใน Drive ของบัญชีที่เชื่อมต่อ", Cloud],
  ["Review First", "ตรวจทานเฉลยและคะแนนก่อนยืนยันผลทุกครั้ง", FileCheck2],
  ["Private by design", "แยกข้อมูลตามบัญชีและตรวจสิทธิ์ที่ฝั่ง Server", ShieldCheck]
] as const;

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background">
      <section className="w-full p-2 sm:p-3">
        <ShaderHero />
      </section>
      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
        <div className="mb-10 max-w-2xl">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">QR EXAM CHECKER</p>
          <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">ตรวจข้อสอบให้เป็นระบบ ตั้งแต่ QR ถึงรายงาน</h2>
          <p className="mt-4 text-muted-foreground">สร้างข้อสอบ จัดการนักเรียน ตรวจใบคำตอบ และเก็บไฟล์บน Google Drive ของเจ้าของบัญชีใน workflow เดียว</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {features.map(([title, text, Icon]) => (
            <article key={title} className="rounded-2xl border bg-card p-6 shadow-sm">
              <Icon className="mb-8 h-5 w-5" />
              <h3 className="font-semibold">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{text}</p>
            </article>
          ))}
        </div>
      </section>
      <footer className="border-t px-5 py-8 text-center text-sm text-muted-foreground">QR Exam Checker · Secure exam workflow</footer>
    </main>
  );
}
