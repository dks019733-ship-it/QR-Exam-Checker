import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { bulkStudentSchema } from "@/lib/answer-sheet";

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = bulkStudentSchema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: "ข้อมูลนักเรียนไม่ถูกต้อง" }, { status: 400 });

  const classroom = await prisma.class.findFirst({
    where: { id: parsed.data.classId, ownerId: session.user.id },
    select: { id: true },
  });
  if (!classroom) return NextResponse.json({ error: "ไม่พบห้องเรียนหรือไม่มีสิทธิ์" }, { status: 404 });

  const normalized = parsed.data.rows.map((row) => ({
    ...row,
    studentNo: row.studentNo.trim(),
    name: row.name.trim(),
    classId: parsed.data.classId,
  }));

  const duplicate = normalized.some((row, i) => normalized.findIndex((x) => x.studentNo === row.studentNo) !== i);
  if (duplicate) return NextResponse.json({ error: "มีรหัสนักเรียนซ้ำในข้อมูลที่ส่งมา" }, { status: 400 });

  await prisma.$transaction(
    normalized.map((row) =>
      prisma.student.upsert({
        where: { classId_studentNo: { classId: row.classId, studentNo: row.studentNo } },
        create: row,
        update: { name: row.name },
      })
    )
  );

  return NextResponse.json({ ok: true, count: normalized.length });
}
