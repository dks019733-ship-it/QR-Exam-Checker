"use client";

import { useEffect, useMemo, useState } from "react";
import { ImagePlus, Plus, Save, Upload, Users, X } from "lucide-react";
import { Button } from "@/components/ui/button";

type Classroom = { id: string; name: string; _count?: { students: number } };
type Student = { id: string; studentNo: string; name: string; qrToken: string };

const emptyStudents = "รหัสนักเรียน,ชื่อ-สกุล\nM401001,นักเรียนตัวอย่าง";

export function AnswerSheetEditor() {
  const [template, setTemplate] = useState({
    schoolName: "โรงเรียนตัวอย่างวิทยา",
    logoDataUrl: "/school-logo-reference.png" as string | null,
    examTitle: "แบบทดสอบวัดผลสัมฤทธิ์ทางการเรียน",
    subject: "วิชาตัวอย่าง",
    questionCount: 40,
    classLabel: "ม.4/1",
  });
  const [classrooms, setClassrooms] = useState<Classroom[]>([]);
  const [classId, setClassId] = useState("");
  const [students, setStudents] = useState<Student[]>([]);
  const [studentText, setStudentText] = useState(emptyStudents);
  const [selectedStudentId, setSelectedStudentId] = useState("");
  const [studentPreview, setStudentPreview] = useState({ studentNo: "M401001", name: "นักเรียนตัวอย่าง", qrToken: "" });
  const [status, setStatus] = useState("");

  useEffect(() => {
    Promise.all([
      fetch("/api/answer-sheet/template").then((r) => r.ok ? r.json() : null),
      fetch("/api/classes").then((r) => r.ok ? r.json() : []),
    ]).then(([saved, classes]) => {
      if (saved) setTemplate({ ...saved, subject: saved.subject ?? "" });
      setClassrooms(classes);
      if (classes[0]) setClassId(classes[0].id);
    });
  }, []);

  useEffect(() => {
    if (!classId) return;
    fetch(`/api/students?classId=${encodeURIComponent(classId)}`)
      .then((r) => r.ok ? r.json() : [])
      .then((rows: Student[]) => {
        setStudents(rows);
        if (rows[0]) {
          setSelectedStudentId(rows[0].id);
          setStudentPreview({ studentNo: rows[0].studentNo, name: rows[0].name, qrToken: rows[0].qrToken });
        }
      });
  }, [classId]);

  const questions = useMemo(() => Array.from({ length: template.questionCount }, (_, i) => i + 1), [template.questionCount]);

  async function saveTemplate() {
    setStatus("กำลังบันทึก...");
    const res = await fetch("/api/answer-sheet/template", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(template),
    });
    setStatus(res.ok ? "บันทึกแบบกระดาษคำตอบแล้ว" : "บันทึกไม่สำเร็จ");
  }

  async function addClass() {
    const name = window.prompt("ชื่อห้องเรียน เช่น ม.4/1");
    if (!name?.trim()) return;
    const res = await fetch("/api/classes", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name }),
    });
    if (!res.ok) return setStatus("สร้างห้องเรียนไม่สำเร็จ");
    const classroom = await res.json();
    setClassrooms((current) => [...current.filter((x) => x.id !== classroom.id), classroom]);
    setClassId(classroom.id);
  }

  async function importStudents() {
    if (!classId) return setStatus("เลือกห้องเรียนก่อน");
    const rows = studentText.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).slice(0, 500);
    const parsed = rows.slice(rows[0]?.toLowerCase().includes("รหัส") || rows[0]?.toLowerCase().includes("student") ? 1 : 0)
      .map((line) => {
        const [studentNo, ...nameParts] = line.split(/[,|\t]/);
        return { studentNo: studentNo?.trim(), name: nameParts.join(",").trim() };
      }).filter((row) => row.studentNo && row.name);
    if (!parsed.length) return setStatus("ไม่พบข้อมูลในรูปแบบ รหัสนักเรียน,ชื่อ-สกุล");

    const res = await fetch("/api/students/bulk", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ classId, rows: parsed }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      return setStatus(body?.error ?? "นำเข้านักเรียนไม่สำเร็จ");
    }
    const refreshed = await fetch(`/api/students?classId=${encodeURIComponent(classId)}`).then((r) => r.json());
    setStudents(refreshed);
    if (refreshed[0]) {
      setSelectedStudentId(refreshed[0].id);
      setStudentPreview({ studentNo: refreshed[0].studentNo, name: refreshed[0].name, qrToken: refreshed[0].qrToken });
    }
    setStatus(`บันทึกนักเรียน ${parsed.length} รายการแล้ว`);
  }

  async function saveStudent() {
    if (!selectedStudentId) return setStatus("เลือกนักเรียนก่อน");
    const res = await fetch(`/api/students/${selectedStudentId}`, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ studentNo: studentPreview.studentNo, name: studentPreview.name }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      return setStatus(body?.error ?? "บันทึกข้อมูลนักเรียนไม่สำเร็จ");
    }
    const updated = await res.json();
    setStudents((current) => current.map((s) => s.id === updated.id ? updated : s));
    setStudentPreview(updated);
    setStatus("บันทึกชื่อและรหัสนักเรียนแล้ว");
  }

  function handleLogo(file?: File) {
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) return setStatus("รองรับเฉพาะ PNG, JPG หรือ WebP");
    if (file.size > 500_000) return setStatus("ไฟล์ตราโรงเรียนต้องไม่เกิน 500 KB");
    const reader = new FileReader();
    reader.onload = () => setTemplate((t) => ({ ...t, logoDataUrl: String(reader.result) }));
    reader.readAsDataURL(file);
  }

  return (
    <main className="min-h-screen bg-background p-5 sm:p-8 print:p-0">
      <div className="mx-auto max-w-7xl">
        <div className="mb-7 flex flex-wrap items-end justify-between gap-4 print:hidden">
          <div>
            <p className="text-sm text-muted-foreground">QR Exam Checker / กระดาษคำตอบ</p>
            <h1 className="mt-1 text-3xl font-semibold tracking-tight">ตั้งค่าและสร้างกระดาษคำตอบ</h1>
            <p className="mt-2 text-sm text-muted-foreground">แก้ตราโรงเรียน ชื่อ วิชา รหัสนักเรียน และชื่อนักเรียนได้จากหน้านี้ โดยข้อมูลที่บันทึกจะผูกกับบัญชีครู</p>
          </div>
          <Button onClick={saveTemplate}><Save className="mr-2 h-4 w-4" />บันทึก</Button>
        </div>

        {status && <div className="mb-5 rounded-xl border bg-card px-4 py-3 text-sm print:hidden">{status}</div>}

        <div className="grid gap-6 lg:grid-cols-[380px_minmax(0,1fr)]">
          <section className="space-y-5 print:hidden">
            <div className="rounded-2xl border bg-card p-5">
              <h2 className="font-semibold">ข้อมูลหัวกระดาษ</h2>
              <div className="mt-4 space-y-4">
                <label className="block text-sm">ชื่อโรงเรียน<input value={template.schoolName} onChange={(e) => setTemplate({ ...template, schoolName: e.target.value })} className="mt-1.5 h-10 w-full rounded-xl border bg-background px-3 outline-none focus:ring-2" /></label>
                <label className="block text-sm">ชื่อแบบทดสอบ<input value={template.examTitle} onChange={(e) => setTemplate({ ...template, examTitle: e.target.value })} className="mt-1.5 h-10 w-full rounded-xl border bg-background px-3 outline-none focus:ring-2" /></label>
                <label className="block text-sm">วิชาที่สอบ<input value={template.subject} onChange={(e) => setTemplate({ ...template, subject: e.target.value })} className="mt-1.5 h-10 w-full rounded-xl border bg-background px-3 outline-none focus:ring-2" /></label>
                <label className="block text-sm">จำนวนข้อ<input type="number" min={1} max={100} value={template.questionCount} onChange={(e) => setTemplate({ ...template, questionCount: Math.max(1, Math.min(100, Number(e.target.value) || 1)) })} className="mt-1.5 h-10 w-full rounded-xl border bg-background px-3 outline-none focus:ring-2" /></label>
                <label className="block text-sm">ชั้น / ห้อง<input value={template.classLabel} onChange={(e) => setTemplate({ ...template, classLabel: e.target.value })} className="mt-1.5 h-10 w-full rounded-xl border bg-background px-3 outline-none focus:ring-2" /></label>
              </div>
            </div>

            <div className="rounded-2xl border bg-card p-5">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold">ตราโรงเรียน</h2>
                {template.logoDataUrl && <button className="text-muted-foreground hover:text-foreground" onClick={() => setTemplate({ ...template, logoDataUrl: null })}><X className="h-4 w-4" /></button>}
              </div>
              <div className="mt-4 flex items-center gap-4">
                <div className="flex h-20 w-20 items-center justify-center rounded-xl border bg-background p-2">
                  {template.logoDataUrl ? <img src={template.logoDataUrl} alt="ตราโรงเรียน" className="max-h-full max-w-full object-contain" /> : <ImagePlus className="h-6 w-6 text-muted-foreground" />}
                </div>
                <label className="cursor-pointer rounded-xl border px-4 py-2 text-sm hover:bg-muted">
                  เปลี่ยนตราโรงเรียน<input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => handleLogo(e.target.files?.[0])} />
                </label>
              </div>
            </div>

            <div className="rounded-2xl border bg-card p-5">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold">ห้องเรียน</h2>
                <button onClick={addClass} className="rounded-lg p-1.5 hover:bg-muted"><Plus className="h-4 w-4" /></button>
              </div>
              <select value={classId} onChange={(e) => {
                const nextId = e.target.value;
                setClassId(nextId);
                const selected = classrooms.find((c) => c.id === nextId);
                if (selected) setTemplate((t) => ({ ...t, classLabel: selected.name }));
              }} className="mt-3 h-10 w-full rounded-xl border bg-background px-3">
                <option value="">เลือกห้องเรียน</option>
                {classrooms.map((c) => <option key={c.id} value={c.id}>{c.name} {c._count ? `(${c._count.students} คน)` : ""}</option>)}
              </select>
            </div>

            <div className="rounded-2xl border bg-card p-5">
              <div className="flex items-center gap-2"><Users className="h-4 w-4" /><h2 className="font-semibold">ใส่ชื่อและรหัสนักเรียน</h2></div>
              <p className="mt-2 text-xs leading-5 text-muted-foreground">วางข้อมูลแบบ CSV/ตาราง โดยใช้รูปแบบ <code>รหัสนักเรียน,ชื่อ-สกุล</code> ระบบจะสร้างหรืออัปเดตข้อมูลในห้องที่เลือก</p>
              <textarea value={studentText} onChange={(e) => setStudentText(e.target.value)} rows={7} className="mt-3 w-full rounded-xl border bg-background p-3 font-mono text-xs outline-none focus:ring-2" />
              <Button variant="outline" className="mt-3 w-full" onClick={importStudents}><Upload className="mr-2 h-4 w-4" />นำเข้าข้อมูลนักเรียน</Button>
              {students.length > 0 && (
                <select className="mt-3 h-10 w-full rounded-xl border bg-background px-3 text-sm" value={selectedStudentId} onChange={(e) => {
                  const s = students.find((x) => x.id === e.target.value);
                  if (s) {
                    setSelectedStudentId(s.id);
                    setStudentPreview({ studentNo: s.studentNo, name: s.name, qrToken: s.qrToken });
                  }
                }}>
                  {students.map((s) => <option key={s.id} value={s.id}>{s.studentNo} — {s.name}</option>)}
                </select>
              )}
            </div>

            <div className="rounded-2xl border bg-card p-5">
              <h2 className="font-semibold">แก้ข้อมูลของใบนี้โดยตรง</h2>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <label className="text-sm">รหัสนักเรียน<input value={studentPreview.studentNo} onChange={(e) => setStudentPreview({ ...studentPreview, studentNo: e.target.value })} className="mt-1.5 h-10 w-full rounded-xl border bg-background px-3" /></label>
                <label className="text-sm">ชื่อ-สกุล<input value={studentPreview.name} onChange={(e) => setStudentPreview({ ...studentPreview, name: e.target.value })} className="mt-1.5 h-10 w-full rounded-xl border bg-background px-3" /></label>
              </div>
              <Button variant="outline" className="mt-3 w-full" onClick={saveStudent}><Save className="mr-2 h-4 w-4" />บันทึกชื่อและรหัสนักเรียน</Button>
            </div>
          </section>

          <section className="rounded-2xl border bg-card p-4 sm:p-6 print:border-0 print:p-0">
            <div className="mb-4 flex items-center justify-between print:hidden">
              <div>
                <h2 className="font-semibold">ตัวอย่างก่อนพิมพ์</h2>
                <p className="text-xs text-muted-foreground">โครงสร้างยึดตามแบบกระดาษคำตอบที่ส่งมา</p>
              </div>
              <button onClick={() => window.print()} className="rounded-xl border px-3 py-2 text-sm hover:bg-muted">พิมพ์ / บันทึก PDF</button>
            </div>
            <AnswerSheetPreview template={template} student={studentPreview} questions={questions} />
          </section>
        </div>
      </div>
    </main>
  );
}

function AnswerSheetPreview({ template, student, questions }: {
  template: { schoolName: string; logoDataUrl: string | null; examTitle: string; subject: string; questionCount: number; classLabel: string };
  student: { studentNo: string; name: string; qrToken: string };
  questions: number[];
}) {
  return (
    <div className="mx-auto w-full max-w-[794px] bg-white p-6 text-black shadow-sm print:shadow-none print:p-0" style={{ minHeight: "1123px" }}>
      <header className="flex items-center gap-5 border-b pb-4">
        <div className="flex h-20 w-20 shrink-0 items-center justify-center">
          {template.logoDataUrl ? <img src={template.logoDataUrl} alt="" className="max-h-20 max-w-20 object-contain" /> : <div className="flex h-16 w-16 items-center justify-center rounded-full border text-[10px] text-gray-500">ตราโรงเรียน</div>}
        </div>
        <div className="min-w-0 flex-1 text-center">
          <h3 className="text-xl font-bold">{template.schoolName}</h3>
          <p className="mt-1 text-sm">{template.examTitle}</p>
          <p className="mt-1 text-sm">วิชา {template.subject} · ชั้น {template.classLabel}</p>
        </div>
        <div className="w-20 shrink-0 text-center text-[10px] text-gray-500">QR<br/>ประจำตัว</div>
      </header>

      <div className="mt-4 grid grid-cols-2 gap-x-8 gap-y-2 border-y py-3 text-sm">
        <div>ชื่อ-สกุล: <span className="font-semibold">{student.name || "________________________"}</span></div>
        <div>รหัสประจำตัวนักเรียน: <span className="font-semibold">{student.studentNo || "____________"}</span></div>
        <div>เลขที่: __________</div>
        <div>ห้อง: {template.classLabel}</div>
        <div>วันที่สอบ: ____ / ____ / ______</div>
        <div>วิชา: {template.subject}</div>
      </div>

      <div className="mt-4 rounded-lg border p-3 text-xs">
        <p className="font-semibold">คำชี้แจง</p>
        <ol className="mt-1 list-decimal space-y-0.5 pl-5">
          <li>ทำเครื่องหมายวงกลมเลือกคำตอบที่ถูกต้องเพียงข้อเดียวในแต่ละข้อ</li>
          <li>ใช้ดินสอ 2B ในการระบายคำตอบ</li>
          <li>หากต้องการเปลี่ยนคำตอบ ให้ลบให้สะอาด แล้วระบายคำตอบใหม่</li>
          <li>ห้ามขีด เขียน หรือทำเครื่องหมายอื่น ๆ ในกระดาษคำตอบ</li>
        </ol>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4">
        {[questions.slice(0, Math.ceil(questions.length / 2)), questions.slice(Math.ceil(questions.length / 2))].map((column, colIndex) => (
          <div key={colIndex} className="overflow-hidden rounded-lg border">
            <div className="grid grid-cols-[40px_repeat(4,1fr)] border-b bg-gray-50 text-center text-xs font-semibold">
              <div className="border-r p-2">ข้อ</div><div className="p-2">A</div><div className="p-2">B</div><div className="p-2">C</div><div className="p-2">D</div>
            </div>
            {column.map((q) => (
              <div key={q} className="grid grid-cols-[40px_repeat(4,1fr)] border-b last:border-b-0 text-center text-xs">
                <div className="border-r p-1.5 font-semibold">{q}</div>
                {["A", "B", "C", "D"].map((choice) => <div key={choice} className="flex items-center justify-center p-1.5"><span className="flex h-6 w-6 items-center justify-center rounded-full border border-gray-600">{choice}</span></div>)}
              </div>
            ))}
          </div>
        ))}
      </div>

      <footer className="mt-5 grid grid-cols-[1fr_220px] gap-5 rounded-lg border p-4 text-xs">
        <div><p>หมายเหตุ :</p><div className="mt-7 border-b" /><div className="mt-6 border-b" /></div>
        <div className="border-l pl-5"><p>ลงชื่อผู้ตรวจ</p><div className="mt-8 border-b" /><p className="mt-3">วันที่ ____ / ____ / ______</p></div>
      </footer>
    </div>
  );
}
