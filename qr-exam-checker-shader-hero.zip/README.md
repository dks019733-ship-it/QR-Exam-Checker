# QR Exam Checker

Starter architecture for a production-oriented exam checking platform.

## Stack
- Next.js App Router + TypeScript
- Tailwind CSS + shadcn/ui structure
- Framer Motion + lucide-react
- NextAuth Google OAuth
- Prisma + PostgreSQL
- Google Drive OAuth scope (`drive.file`)

## Run

```bash
npm install
cp .env.example .env
npx prisma generate
npx prisma db push
npm run dev
```

## Google OAuth

Create an OAuth 2.0 Web application in Google Cloud Console. Add the callback:

`http://localhost:3000/api/auth/callback/google`

Set `AUTH_GOOGLE_ID`, `AUTH_GOOGLE_SECRET`, and `AUTH_SECRET`.

The app requests `drive.file`, which is intentionally narrower than full Drive access. Drive integration should create and manage only files/folders created or opened by this app.

## Security rules
1. Every server-side query must scope by authenticated `user.id`.
2. Never trust `ownerId`, `classId`, `examId`, or `studentId` from the client without re-checking ownership.
3. Store Google refresh tokens server-side only; never expose them to browser code.
4. Do not auto-confirm ambiguous OCR/OMR results.
5. Keep audit history for score edits/confirmation before enabling destructive deletion.
6. Prefer archive/soft-delete workflows for exam data.

## 21st.dev component
`components/ui/prisma-hero.tsx` is adapted from the supplied 21st.dev Prisma Hero component. The visual language was changed to match QR Exam Checker while retaining the component's animation approach.


## Answer sheet editor

`/dashboard/answer-sheet` adds the first production-oriented answer-sheet workflow:
- Edit school name and school logo.
- Edit exam title, subject, class, and question count.
- Import student number + name in CSV/TSV-style rows.
- Preview an individual student's sheet and print/save it as PDF.
- All API queries are scoped to the authenticated owner.

The logo is validated as PNG/JPEG/WebP and limited to 500 KB. It is stored with the owner-scoped answer-sheet template so it does not depend on a public upload directory.
